import pandas as pd
from ds_colombia.clv.clv_churn import df_to_clv

"""How to use?
Basically, if you have transactional data with:
- Customer unique identifier column
- Date of transaction column
- Value of transaction column

You can call the df_to_clv function and return a CLV/Churn DataFrame
"""

df = pd.read_parquet('../data/clv_churn/CLV_customer_date_value.parquet.gzip')

clv = df_to_clv(df, customer_column='CustomerID',
                date_column='SaleDate', value_column='SaleTotalPrice')

clv.to_excel('../data/clv_churn/test_CLV.xlsx')
