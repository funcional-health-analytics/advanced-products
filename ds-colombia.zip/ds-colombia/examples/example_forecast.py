import pandas as pd

from ds_colombia.forecast.forecast import df_to_forecast

"""How to use?
Basically, if you have data with:
- Date column
- Value column

You can call the df_to_forecast function to generate forecast artifacts:
- Static plots: forecast and forecast components
- Interactive plot: forecast
- Forecast spreadsheet with date and values
"""

df = pd.read_parquet('../data/forecast/sales.parquet.gzip')

df_to_forecast(df,
               date_column='SaleDate',
               value_column='SaleTotalPrice',
               frequency='D',
               path='../data/forecast',
               growth='logistic',
               cap_value=2e9,
               period=365,
               floor_value=0,
               daily_seasonality=False,
               weekly_seasonality=True,
               yearly_seasonality=True,
               seasonality_mode='additive')
