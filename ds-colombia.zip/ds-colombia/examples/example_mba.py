import pandas as pd

from ds_colombia.market_basket_analysis.mba import df_to_mba

"""How to use?
Basically, if you have data with:
- Order column
- Quantity column
- Product column 

You can call the df_to_mba function to generate market basket analysis artifacts:
- Interactive plot: rules
- Rules spreadsheet
- Recommendation table spreadsheet
"""

df = pd.read_parquet('../data/mba/online_sales.parquet.gzip')

df_to_mba(df,
          product_column='ProductID',
          quantity_column='SalesUnit',
          order_column='SalesOrderID',
          path='../data/mba/'
          )
