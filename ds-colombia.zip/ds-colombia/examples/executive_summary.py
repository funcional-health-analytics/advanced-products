import pandas as pd

from ds_colombia.clv.clv_churn import df_to_clv


def executive_summary(current_clv, old_clv):
    """Compute the variation between two CLV tables

    Arguments:
        current_clv {pandas DataFrame} -- Most up to date CLV table
        old_clv {pandas DataFrame} -- Older CLV table

    Returns:
        parameters -- Returns the unified Dataframe and the percentuals
    """
    old_clv = old_clv.rename(
        columns={'clv': 'old_clv', 'p_alive': 'old_p_alive'})
    unified = current_clv.merge(old_clv, on='id')
    unified = unified[unified['clv'] >= 0]
    unified = unified[unified['old_clv'] >= 0]
    unified['delta_clv'] = unified['clv'] - unified['old_clv']
    unified['delta_p_alive'] = unified['p_alive'] - unified['old_p_alive']
    pct_delta_clv = 100*unified['delta_clv'].sum()/unified['old_clv'].sum()
    pct_delta_p_alive = 100 * \
        unified['delta_p_alive'].sum()/unified['old_p_alive'].sum()

    print('The difference in CLV is {}%'.format(round(pct_delta_clv, 2)))
    print('The difference in P_Alive is {}%'.format(round(pct_delta_p_alive, 2)))

    return unified, pct_delta_clv, pct_delta_p_alive


def rolling_window_clv(df, date_column, customer_column, value_column, n_windows=10):
    """Computes the rolling window CLV

    Arguments:
        df {pandas DataFrame} -- Transactional data
        date_column {str} -- Name of the date column
        customer_column {str} -- Name of the customer column
        value_column {str} -- Name of the value column

    Keyword Arguments:
        n_windows {int} -- Number of month windows to compute (default: {10})

    Returns:
        pandas DataFrame -- Consolidated table with the values for each
        customer at each monthly window
    """
    end_date = str(df[date_column].max()-pd.DateOffset(months=0))[:10]
    final_clv = df_to_clv(df,
                          customer_column=customer_column,
                          date_column=date_column,
                          value_column=value_column,
                          end_date=end_date).reset_index()[['id', 'clv', 'p_alive']]
    final_clv = final_clv.rename(columns={'clv': 'clv_' + end_date,
                                          'p_alive': 'p_alive_' + end_date})
    for i in range(1, n_windows):
        end_date = str(df[date_column].max()-pd.DateOffset(months=i))[:10]
        clv = df_to_clv(df,
                        customer_column='CustomerID',
                        date_column='SaleDate',
                        value_column='SaleTotalPrice',
                        end_date=end_date).reset_index()[['id', 'clv', 'p_alive']]
        clv = clv.rename(columns={'clv': 'clv_' + end_date,
                                  'p_alive': 'p_alive_' + end_date})
        final_clv = final_clv.merge(clv, on='id')

    return final_clv
