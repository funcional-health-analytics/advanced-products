===============
Getting started
===============

Installation
------------

You can install this package from source::

    # clone the repository
    $ git clone https://github.com/funcional-health-analytics/ds-colombia.git
    
    # open the folder
    $ cd ds-colombia
    
    # install the dependencies
    $ pip install -e .