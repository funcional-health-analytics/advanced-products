===
API
===

This is a list with all relevant **ds_colombia** functions.
Docstrings should provide enough information in order to understand any individual function.


Advanced Analytics Functions
----------------------------

Customer Lifetime Value / Churn (ds_colombia.clv_churn)
#######################################################

.. currentmodule:: ds_colombia.clv_churn

.. autosummary::
   create_transactional_table
   create_summary_table
   fit_models
   compute_clv
   cluster_by_clv
   cluster_by_churn
   df_to_clv

Forecast (ds_colombia.forecast)
###############################

.. currentmodule:: ds_colombia.forecast

.. autosummary::
   prepare_df
   saturate_limits
   fit_model
   make_forecast_df
   save_static_plots
   save_interactive_plot
   save_values_spreadsheet
   df_to_forecast

Market Basket Analysis (ds_colombia.mba)
########################################

.. currentmodule:: ds_colombia.mba

.. autosummary::
   filter_top_products
   prepare_dataset
   create_rules_table
   create_recommendation_table
   save_interactive_plot
   save_rules_spreadsheet
   save_recommendation_spreadsheet
   df_to_mba

Definitions
-----------

.. automodule:: ds_colombia.clv_churn
   :members:

.. automodule:: ds_colombia.forecast
   :members:

.. automodule:: ds_colombia.mba
   :members: