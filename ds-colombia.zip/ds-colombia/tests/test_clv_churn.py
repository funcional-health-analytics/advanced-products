import unittest
import pandas as pd
from ds_colombia.clv.clv_churn import (create_transactional_table,
                                       create_summary_table,
                                       fit_models,
                                       compute_clv,
                                       cluster_by_clv,
                                       cluster_by_churn,
                                       df_to_clv)


# given
df = pd.DataFrame(
    {
        'customer': ['customer1',
                     'customer2',
                     'customer1',
                     'customer2',
                     'customer1',
                     'customer2'],
        'value': [1,
                  2,
                  1,
                  2,
                  1,
                  2],
        'time': [pd.to_datetime("2016-10-01"),
                 pd.to_datetime("2016-10-01"),
                 pd.to_datetime("2016-11-01"),
                 pd.to_datetime("2016-11-01"),
                 pd.to_datetime("2016-12-01"),
                 pd.to_datetime("2016-12-01")]
    }
)

transactional = create_transactional_table(df, 'customer', 'time', 'value')
summary = create_summary_table(transactional, 'value', end_date='2018-01-01')
ggf, bgf = fit_models(summary, penalizer_coef=0.01)
clv = compute_clv(ggf, bgf, summary)
clv_cluster = cluster_by_clv(clv)
clv_churn = cluster_by_churn(clv_cluster)
final_clv = df_to_clv(df, 'customer', 'time', 'value', end_date='2018-01-01')


class TestClvChurn(unittest.TestCase):

    def test_create_transactional_table(self):
        self.assertListEqual(list(transactional.columns.values), [
                             'date', 'id', 'value'],
                             "Transactional table must have ['date', 'id', 'value'] columns")
        self.assertEqual(df.shape[0], transactional.shape[0],
                         'Shapes from input and output must be the same')
        self.assertEqual(transactional['date'].dtype, '<M8[ns]')
        self.assertIsNot(transactional['value'].dtype, 'object')

    def test_create_summary_table(self):
        self.assertListEqual(list(summary.columns.values), [
                             'frequency', 'recency', 'T', 'monetary_value'],
                             "Summary table must have ['frequency', 'recency', 'T', 'monetary_value'] columns")
        self.assertEqual(df['customer'].nunique(), summary.shape[0],
                         'N_rows must be equal unique customers')

    def test_fit_models(self):
        self.assertEqual(len(ggf.params_.values), 3,
                         "GammaGamma model must have 3 parameters: p, q, v")
        self.assertEqual(len(bgf.params_.values), 4,
                         "BetaGeo model must have 4 parameters: r, alpha, a, b")

    def test_compute_clv(self):
        self.assertEqual(clv.shape[0], df['customer'].nunique(
        ), "N_rows on CLV table must be equal to unique customers")
        self.assertListEqual(list(clv.index), list(
            df['customer'].unique()), "Customers on the CLV table must be the same from df")
        self.assertListEqual(list(clv.columns.values), [
                             'clv', 'p_alive'], "Initial CLV table must have ['clv', 'p_alive'] columns")

    def test_cluster_by_clv(self):
        self.assertIn('clv_group', list(clv_cluster.columns))
        self.assertEqual(clv_cluster.shape[0], df['customer'].nunique(
        ), "N_rows on CLV table must be equal to unique customers")
        self.assertListEqual(list(clv_cluster.index), list(
            df['customer'].unique()), "Customers on the CLV table must be the same from df")

    def test_cluster_by_churn(self):
        self.assertIn('retention_groups', list(clv_churn.columns))
        self.assertEqual(clv_churn.shape[0], df['customer'].nunique(
        ), "N_rows on CLV table must be equal to unique customers")
        self.assertListEqual(list(clv_churn.index), list(
            df['customer'].unique()), "Customers on the CLV table must be the same from df")

    def test_df_to_clv(self):
        self.assertEqual(final_clv.shape[0], df['customer'].nunique(
        ), "N_rows on CLV table must be equal to unique customers")
        self.assertListEqual(list(final_clv.index), list(
            df['customer'].unique()), "Customers on the CLV table must be the same from df")
        self.assertListEqual(list(final_clv.columns.values), [
                             'clv', 'p_alive', 'clv_group', 'retention_groups'],
                             "CLV table must have the ['clv', 'p_alive', 'clv_group', 'retention_groups'] columns")
