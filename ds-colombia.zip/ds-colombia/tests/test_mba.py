import unittest
import pandas as pd
from ds_colombia.market_basket_analysis.mba import (filter_top_products,
                                                    prepare_dataset,
                                                    create_rules_table,
                                                    create_recommendation_table)


df = pd.DataFrame(
    {
        'product': ['product_1',
                    'product_2',
                    'product_1',
                    'product_2',
                    'product_1',
                    'product_2'],
        'unit': [1,
                 2,
                 1,
                 2,
                 1,
                 2],
        'order': [2,
                  2,
                  1,
                  1,
                  1,
                  2]
    }
)

n_products = 5
filtered_df = filter_top_products(df, n_products, product_column='product',
                                  quantity_column='unit')
prepared_df = prepare_dataset(filtered_df, product_column='product',
                              quantity_column='unit', order_column='order')
rules = create_rules_table(
    prepared_df, min_support=0.00005, max_len=2, use_colnames=True)
rec_table = create_recommendation_table(rules)


class TestMarketBasketAnalysis(unittest.TestCase):

    def test_filter_top_products(self):
        self.assertLessEqual(filtered_df['product'].nunique(), n_products,
                             "Dataset must have less than the number of products!")

    def test_prepare_dataset(self):
        self.assertEqual(filtered_df['order'].nunique(), prepared_df.shape[0],
                         "Number of orders must be equal to the number of rows!")
        self.assertEqual(filtered_df['product'].nunique(), prepared_df.shape[1],
                         "Number of products must be equal to the number of columns!")

    def test_create_rules_table(self):
        self.assertListEqual(list(rules.columns.values),
                             ['antecedents', 'consequents', 'antecedent support',
                              'consequent support', 'support', 'confidence', 'lift', 'leverage',
                              'conviction'],
                             "Rules columns don't match expected")

    def test_create_recommendation_table(self):
        self.assertListEqual(list(rec_table.columns.values),
                             ['antecedents', 'consequents'],
                             "Recommendation table columns don't match expected")
