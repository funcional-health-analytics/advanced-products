import unittest
import pandas as pd
from ds_colombia.forecast.forecast import (prepare_df,
                                           saturate_limits,
                                           fit_model,
                                           make_forecast_df)


# given
df = pd.DataFrame(
    {
        'value': [1,
                  2,
                  1,
                  2,
                  1,
                  2],
        'time': [pd.to_datetime("2016-10-01"),
                 pd.to_datetime("2016-10-01"),
                 pd.to_datetime("2016-11-01"),
                 pd.to_datetime("2016-11-01"),
                 pd.to_datetime("2016-12-01"),
                 pd.to_datetime("2016-12-01")]
    }
)

df_p = prepare_df(df, 'time', 'value')
df_p_sat = saturate_limits(df_p, cap_value=5, floor_value=0)
model = fit_model(df_p_sat)
period = 10
forecast = make_forecast_df(model, cap_value=5, floor_value=0, period=period)


class TestForecast(unittest.TestCase):

    def test_prepare_df(self):
        self.assertListEqual(list(df_p.columns.values), [
                             'ds', 'y'],
                             "Prepared table must have ['ds', 'y'] columns")
        self.assertEqual(df_p['ds'].dtype, '<M8[ns]')
        self.assertIsNot(df_p['y'].dtype, 'object')

    def test_create_summary_table(self):
        self.assertListEqual(list(df_p_sat.columns.values), [
                             'ds', 'y', 'floor', 'cap'],
                             "Prepared table must have ['ds', 'y', 'cap', 'floor'] columns")
        self.assertNotEqual(df_p_sat['cap'][0], df_p_sat['floor'][0],
                            "Cap value and Floor value must not be equal!")

    def test_fit_models(self):
        self.assertListEqual(list(model.params.keys()),
                             ['k', 'm', 'delta', 'sigma_obs', 'beta'],
                             "Fitted model must have the following parameters ['k', 'm', 'delta', 'sigma_obs', 'beta']")

    def test_make_forecast_df(self):
        self.assertListEqual(list(forecast.columns.values),
                             ['ds', 'trend', 'cap', 'floor', 'yhat_lower', 'yhat_upper',
                              'trend_lower', 'trend_upper', 'additive_terms', 'additive_terms_lower',
                              'additive_terms_upper', 'weekly', 'weekly_lower', 'weekly_upper',
                              'yearly', 'yearly_lower', 'yearly_upper', 'multiplicative_terms',
                              'multiplicative_terms_lower', 'multiplicative_terms_upper', 'yhat'],
                             "Forecast columns don't match expected")
        self.assertEqual(df_p_sat.shape[0]+period,
                         forecast.shape[0],
                         "Forecast DataFrame must be N periods longer than original DataFrame")
