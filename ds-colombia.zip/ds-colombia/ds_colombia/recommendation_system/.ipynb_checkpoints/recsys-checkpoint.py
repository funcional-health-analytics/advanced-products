import pandas as pd
import turicreate as tc


def prepare_sales(df: pd.DataFrame, customer_column: str, product_column: str) -> pd.DataFrame:
    """
    Filters only essential columns for RecSys
    Args:
        df:
        customer_column:
        product_column:

    Returns:

    """
    return df[[customer_column, product_column]].copy()


def dataframe_to_sframe(df: pd.DataFrame) -> tc.SFrame:
    """
    Transforms pandas dataframe to turicreate SFrame
    Args:
        df:

    Returns:

    """
    return tc.SFrame(df)


def fit_popularity_recommender(data: tc.SFrame,
                               customer_column: str,
                               product_column: str) -> tc.recommender.popularity_recommender.PopularityRecommender:
    """
    Fits popularity recommender
    Args:
        data:
        customer_column:
        product_column:

    Returns:

    """
    return tc.recommender.popularity_recommender.create(data, user_id=customer_column, item_id=product_column)


def fit_item_similarity_recommender(
        data: tc.SFrame,
        customer_column: str,
        product_column: str) -> tc.recommender.item_similarity_recommender.ItemSimilarityRecommender:
    """
    Fits item similarity recommender
    Args:
        data:
        customer_column:
        product_column:

    Returns:

    """
    return tc.recommender.item_similarity_recommender.create(data, user_id=customer_column, item_id=product_column)


def fit_ranking_factorization_recommender(
        action_data: tc.SFrame,
        customer_column: str,
        product_column: str,
        customer_data: tc.SFrame,
        product_data: tc.SFrame) -> tc.recommender.ranking_factorization_recommender.RankingFactorizationRecommender:
    """
    Fits ranking factorization recommender
    Args:
        action_data:
        customer_column:
        product_column:
        customer_data:
        product_data:

    Returns:

    """
    return tc.recommender.ranking_factorization_recommender.create(action_data,
                                                                   user_id=customer_column,
                                                                   item_id=product_column,
                                                                   user_data=customer_data,
                                                                   item_data=product_data)


def make_recommendations(
        model: tc.recommender.ranking_factorization_recommender.RankingFactorizationRecommender,
        n_recommendations: int = 10,
        exclude_known: bool = False,
        users: list = None) -> pd.DataFrame:
    """
    Makes recommendation from trained model
    Args:
        model:
        n_recommendations:
        exclude_known:
        users:

    Returns:

    """
    if users is not None:
        recommendations_table = model.recommend(users,
                                                k=n_recommendations,
                                                exclude_known=exclude_known).to_dataframe()
    else:
        recommendations_table = model.recommend(k=n_recommendations,
                                                exclude_known=exclude_known).to_dataframe()
    return recommendations_table


def evaluate_recommendation_model(
        model: tc.recommender.ranking_factorization_recommender.RankingFactorizationRecommender,
        action_data: tc.SFrame,
        exclude_known: bool = False):
    """
    Evaluates recommendation model
    Args:
        exclude_known:
        model:
        action_data:

    Returns:

    """
    return model.evaluate_precision_recall(action_data, exclude_known=exclude_known)
