from typing import Tuple
import pandas as pd
from tqdm import tqdm


# def load_data(sales_path: str,
#               stores_path: str,
#               products_path: str,
#               quantity_column: str,
#               date_column: str,
#               product_name: str,
#               product_granularity: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
#     sales = pd.read_parquet(
#         f"{sales_path}",
#         columns=[
#             date_column,
#             "CustomerID",
#             "StoreID",
#             "ProductID",
#             quantity_column,
#         ],
#     )
#     sales = sales[sales["CustomerID"] != "N/A"]
#     sales = sales[sales["CustomerID"] != -1]

#     sales = sales[sales[date_column] >= "2019-01"]

#     stores = pd.read_parquet(
#         f"{stores_path}", columns=["StoreID", "StoreName"]
#     )
#     products = pd.read_parquet(
#         f"{products_path}",
#         columns=["ProductID", product_name, product_granularity],
#     )

#     return sales, stores, products


def find_suspects(transactions_last_month: pd.DataFrame,
                  current_df: pd.DataFrame,
                  reference_df: pd.DataFrame,
                  stddev: int,
                  customer_column: str,
                  store_column: str,
                  product_granularity: str,
                  product_name: str,
                  quantity_column: str,
                  date_column: str):
    # Fill suspects array with CustomerIDs
    suspects = pd.DataFrame(
        columns=[
            customer_column,
            product_granularity,
            "Unit_by_user_mean",
            "Unit_by_user_std",
            "customer_unities",
            "transactions",
        ]
    )
    for product_group in tqdm(reference_df[product_granularity].unique()):
        try:
            if product_group == "N/A":
                continue
            higher = (
                reference_df[reference_df[product_granularity] == product_group][
                    "Unit_by_user_mean"
                ].values[0]
                + stddev
                * reference_df[reference_df[product_granularity] == product_group][
                    "Unit_by_user_mean_std"
                ].values[0]
            )
            list_customers = current_df[current_df[product_group] > higher].index.values
            value_customers = current_df[current_df[product_group] > higher][product_group].values
            aux = pd.DataFrame(
                columns=[
                    customer_column,
                    product_granularity,
                    "Unit_by_user_mean",
                    "Unit_by_user_std",
                    "customer_unities",
                    "transactions",
                ]
            )
            t_product_group = transactions_last_month[transactions_last_month[product_granularity] == product_group]
            for i in range(len(list_customers)):
                if t_product_group[product_granularity].values[0] == "VITAMINAS":
                    continue
                aux.loc[i, customer_column] = list_customers[i]
                aux.loc[i, product_granularity] = t_product_group[
                    product_granularity
                ].values[0]
                aux.loc[i, product_granularity] = product_group
                aux.loc[i, "Unit_by_user_mean"] = round(
                    reference_df[reference_df[product_granularity] == product_group][
                        "Unit_by_user_mean"
                    ].values[0],
                    2,
                )
                aux.loc[i, "Unit_by_user_std"] = round(
                    reference_df[reference_df[product_granularity] == product_group][
                        "Unit_by_user_mean_std"
                    ].values[0],
                    2,
                )
                aux.loc[i, "customer_unities"] = value_customers[i]
                t_product_group_customer = t_product_group[t_product_group[customer_column] == list_customers[i]]
                string_transactions = ""
                for j in range(t_product_group_customer.shape[0]):
                    string_transactions += """SalesDate: {} StoreName: {} ProductName: {} ActivePrincipal: {}, SalesUnit: {}\n""".format(
                        str(t_product_group_customer[date_column].values[j])[:19],
                        t_product_group_customer[store_column].values[j],
                        t_product_group_customer[product_name].values[j],
                        t_product_group_customer[product_granularity].values[j],
                        t_product_group_customer[quantity_column].values[j],
                    )

                aux.loc[i, "transactions"] = string_transactions
        except Exception as e:
            print(e)
            continue

        suspects = pd.concat([suspects, aux])

    return suspects


def get_transactions_last_month(full_view: pd.DataFrame,
                                customer_column: str,
                                product_granularity: str,
                                quantity_column: str,
                                date_column: str) -> Tuple[pd.DataFrame, pd.DataFrame]:

    last_month = full_view[date_column].max() - pd.DateOffset(months=1)
    transactions_last_month = full_view[full_view[date_column] >= last_month]

    sparse_matrix_last_month = (
        transactions_last_month.groupby(by=[customer_column, product_granularity])[
            quantity_column
        ]
        .sum()
        .unstack()
        .fillna(0)
    )

    return transactions_last_month, sparse_matrix_last_month


def get_reference_table(df: pd.DataFrame,
                        customer_column: str,
                        product_granularity: str,
                        quantity_column: str,
                        date_column: str) -> pd.DataFrame:
    reference_df = df[df[date_column] < df[date_column].max() - pd.DateOffset(months=1)]
    reference_df = reference_df[reference_df[date_column] >= reference_df[date_column].max() - pd.DateOffset(months=12)]

    reference_table = pd.DataFrame(
        columns=[
            product_granularity,
            "Unit_by_user_mean",
            "Unit_by_user_mean_std",
        ]
    )
    for product_description in tqdm(reference_df[product_granularity].unique()):
        aux = pd.DataFrame(
            columns=[
                product_granularity,
                "Unit_by_user_mean",
                "Unit_by_user_mean_std",
            ]
        )
        aux.loc[0, product_granularity] = product_description
        aux.loc[0, "Unit_by_user_mean"] = (
            reference_df[reference_df[product_granularity] == product_description]
            .groupby(by=customer_column)[quantity_column]
            .sum()
            .mean()
        )
        aux.loc[0, "Unit_by_user_mean_std"] = (
            reference_df[reference_df[product_granularity] == product_description]
            .groupby(by=customer_column)[quantity_column]
            .sum()
            .std()
        )

        reference_table = pd.concat([reference_table, aux])
        reference_table = reference_table.reset_index(drop=True)

    return reference_table
