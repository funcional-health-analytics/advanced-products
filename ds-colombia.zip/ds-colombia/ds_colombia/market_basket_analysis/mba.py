import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from pandas.api.types import CategoricalDtype
from datetime import datetime
from mlxtend.frequent_patterns import fpgrowth
from mlxtend.frequent_patterns import association_rules
import plotly.express as px
import plotly.offline as py


def filter_top_products(df: pd.DataFrame, n_products: int, product_column: str, quantity_column: str) -> pd.DataFrame:
    """Filter DataFrame for the n top products

    Arguments:
        df {pandas DataFrame} -- DataFrame, probably from sales
        n_products {int} -- Number of top products to keep
        product_column {str} -- Product unique identifier column
        quantity_column {str} -- Column name of the quantity

    Returns:
        pandas DataFrame -- pandas DataFrame filtered by the top n products
    """
    top_prods = list(df.groupby(by=product_column)
                     .sum()
                     .sort_values(by=quantity_column,
                                  ascending=False)
                     .reset_index()[product_column][:n_products])

    df = df[df[product_column].isin(top_prods)]

    return df


def prepare_dataset(df: pd.DataFrame, product_column: str, quantity_column: str, order_column: str) -> pd.DataFrame:
    """Prepare the dataset to create the association rules

    Arguments:
        df {pandas DataFrame} -- DataFrame, probably from sales
        product_column {str} -- Name of the product column
        quantity_column {str} -- Name of the quantity column
        order_column {str} -- Name of the order column

    Returns:
        pandas SparseDataFrame -- Prepared dataset for the association rules
    """
    sale_c = CategoricalDtype(sorted(df[order_column].unique()), ordered=True)
    product_c = CategoricalDtype(sorted(df[product_column].unique()), ordered=True)
    row = df[order_column].astype(sale_c).cat.codes
    col = df[product_column].astype(product_c).cat.codes
    sparse_matrix = csr_matrix((df[quantity_column], (row, col)),
                               shape=(sale_c.categories.size, product_c.categories.size))
    sparse_matrix.data = np.where(sparse_matrix.data > 0, 1, 0)
    basket_sets = pd.DataFrame.sparse.from_spmatrix(sparse_matrix, sale_c.categories, product_c.categories)

    return basket_sets


def create_rules_table(basket_sets: pd.DataFrame,
                       min_support: float = 0.00005,
                       max_len: int = 2,
                       use_colnames: bool = True) -> pd.DataFrame:
    """Create the association rules table from the dataset

    Arguments:
        basket_sets {pandas DataFrame} -- Prepared dataset for the rules

    Keyword Arguments:
        min_support {float} -- Minimum support to accept (default: {0.00005})
        max_len {int} -- Max length of products to compose the rule (default: {2})
        use_colnames {bool} -- Use or not the name of the columns (default: {True})

    Returns:
        pandas DataFrame -- DataFrame with the association rules
    """
    frequent_itemsets = fpgrowth(
        basket_sets, min_support=min_support, use_colnames=use_colnames, max_len=max_len)
    rules = association_rules(
        frequent_itemsets, metric="lift", min_threshold=1)
    rules = rules.sort_values(by='lift', ascending=False)
    rules = rules[['antecedents', 'consequents', 'antecedent support', 'consequent support', 'support', 'confidence',
                   'lift', 'leverage', 'conviction']]
    rules = rules.sort_values(by='lift', ascending=False)
    rules['antecedents'] = rules['antecedents'].apply(lambda x: str(x)[11:-2])
    rules['consequents'] = rules['consequents'].apply(lambda x: str(x)[11:-2])

    return rules


def create_recommendation_table(rules: pd.DataFrame) -> pd.DataFrame:
    """Create a recommendation table from the rules

    Arguments:
        rules {pandas DataFrame} -- Association rules

    Returns:
        pandas DataFrame -- Recommendation table with two columns
    """
    rec_table = rules.copy().dropna()
    cols = ['antecedents', 'consequents']
    for col in cols:
        rec_table[col] = pd.to_numeric(
            rec_table[col], errors='coerce', downcast='integer')

    rec_table = rec_table.dropna()
    rec_table = rec_table.astype(int)

    rec_table = rec_table[['antecedents', 'consequents']]
    rec_table = rec_table.groupby(by='antecedents')[
        'consequents'].apply(list).reset_index()

    return rec_table


def make_interactive_plot(rules: pd.DataFrame, n_rules: int = 500):
    """Makes a plotly interactive plot

    Arguments:
        rules {pandas DataFrame} -- Association rules
        path {str} -- Path to save the plot

    Keyword Arguments:
        n_rules {int} -- Maximum number of rules to plot (default: {500})
    """
    fig = px.scatter(rules[:n_rules],
                     x="support",
                     y="confidence",
                     color="lift",
                     hover_data=['antecedents', 'consequents'],
                     title='Market Basket Analysis')

    return py.plot(fig)


def save_rules_spreadsheet(rules: pd.DataFrame, path: str):
    """Save the association rules to an Excel spreadsheet

    Arguments:
        rules {pandas DataFrame} -- Association rules
        path {str} -- Path to save the spreadsheet
    """
    with pd.ExcelWriter('{}/mba_table_{}.xlsx'.format(path, str(datetime.now())[:10]),
                        engine='xlsxwriter') as writer:
        rules.to_excel(writer, sheet_name='MarketBasketAnalysis', index=False)
        workbook = writer.book
        sheets = ['MarketBasketAnalysis']
        for sheet_name in sheets:
            worksheet = writer.sheets[sheet_name]
            fmt = workbook.add_format({'align': 'center',
                                       'bold': False})
            worksheet.set_zoom(90)
            worksheet.set_column('A:I', 50, fmt)


def save_recommendation_spreadsheet(rec_table: pd.DataFrame, path: str):
    """Saves the Recommendation table to an Excel spreadsheet

    Arguments:
        rec_table {pandas DataFrame} -- Recommendation table
        path {str} -- Path to save the recommendation table
    """
    with pd.ExcelWriter('{}/mba_recommendation_{}.xlsx'.format(path, str(datetime.now())[:10]),
                        engine='xlsxwriter') as writer:
        rec_table.to_excel(
            writer, sheet_name='MarketBasketAnalysis', index=False)
        workbook = writer.book
        sheets = ['MarketBasketAnalysis']
        for sheet_name in sheets:
            worksheet = writer.sheets[sheet_name]
            fmt = workbook.add_format({'align': 'center',
                                       'bold': False})
            worksheet.set_zoom(90)
            worksheet.set_column('A:I', 50, fmt)


def remove_forbidden_products(df: pd.DataFrame, allowed_list: list, filtering_criteria: str):
    """
    Remove products that cannot be recommended to customers, like prescribed medication
    Args:
        df {pandas DataFrame}: Probably sales data
        allowed_list {list}: List of products or categories that can be included in the analysis
        filtering_criteria {str}: string with the column name of the filter target

    Returns:
        Pandas dataframe containing only the products that can be submitted to a MBA analysis
    """
    df = df[df[filtering_criteria].isin(allowed_list)]
    return df


def df_to_mba(df: pd.DataFrame,
              product_column: str,
              quantity_column: str,
              order_column: str,
              n_products: int = 300,
              min_support: float = 0.00005,
              max_len: int = 2,
              use_colnames: bool = True,
              allowed_list: list = None,
              filtering_criteria: str = None,
              filter_products: bool = False):
    """Transform the sales data to MBA artifacts

    Arguments:
        df {pandas DataFrame} -- Probably sales data
        product_column {str} -- Name of the product column
        quantity_column {str} -- Name of the quantity column
        order_column {str} -- Name of the order column
        path {str} -- Path to save the MBA artifacts

    Keyword Arguments:
        n_products {int} -- Number of top products to keep (default: {300})
        n_rules {int} -- Number of rules to plot (default: {500})
        min_support {float} -- Minimum product support to compute the rules (default: {0.00005})
        max_len {int} -- Max number of products to compose a rule (default: {2})
        use_colnames {bool} -- Use or not the column names (default: {True})
        allowed_list {list} -- List that identifies which products can be analysed (default: {None})
        filtering_criteria {str} -- String that informs over which column the products will be filtered(default: {None})
        filter_products {bool} -- Remove or not products from the analysis (default: {False})
    """
    if filter_products:
        sales_df = remove_forbidden_products(df, allowed_list, filtering_criteria)
    else:
        sales_df = df
    filtered_df = filter_top_products(
        sales_df, n_products, product_column, quantity_column)

    basket_sets = prepare_dataset(
        filtered_df, product_column, quantity_column, order_column)

    rules = create_rules_table(basket_sets, min_support, max_len, use_colnames)

    rec_table = create_recommendation_table(rules)

    return rules, rec_table
