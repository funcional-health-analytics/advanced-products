import boto3
import pandas as pd
import io
import awswrangler as wr


def write_xlsx_to_s3(df: pd.DataFrame, bucket: str, path: str, sheet_name: str = 'sheet'):
    """
    Saves an excel file to a s3 bucket in the specified path
    Args:
        df {pandas DataFrame}: DataFrame to be saved
        bucket {str}: bucket name
        path {str}: string of the path inside the bucket where to save the file
        sheet_name {str}: optional, in case a custom sheet name is necessary
    """
    with io.BytesIO() as output:
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, sheet_name)
        data = output.getvalue()
    s3 = boto3.resource('s3')
    s3.Bucket(bucket).put_object(Key=path, Body=data)


def write_csv_to_s3(df: pd.DataFrame, bucket: str, path: str):
    """
    Saves a csv file to a s3 bucket in the specified path
    Args:
        df {pandas DataFrame}: DataFrame to be saved
        bucket {str}: bucket name
        path {str}: string of the path inside the bucket where to save the file
    """
    df.to_csv(f"s3://{bucket}/{path}", index=False)


def write_parquet_to_s3(df: pd.DataFrame, bucket: str, path: str):
    """
    Saves a parquet file to a s3 bucket in the specified path
    Args:
        df {pandas DataFrame}: DataFrame to be saved
        bucket {str}: bucket name
        path {str}: string of the path inside the bucket where to save the file
    """
    wr.s3.to_parquet(df=df,
                     path=f"s3://{bucket}/{path}",
                     compression='gzip')


def save_model_to_s3(model, bucket: str, path: str):
    """
    Saves a machine learning model to a s3 bucket in the specified path
    Args:
        model:
        bucket {str}: bucket name
        path {str}: string of the path inside the bucket where to save the file
    """
    model.save(f"s3://{bucket}/{path}")
