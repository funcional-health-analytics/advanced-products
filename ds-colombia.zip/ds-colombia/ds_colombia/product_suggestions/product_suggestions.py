from typing import Tuple

import pandas as pd


def _flatten(list_to_flatten):
    return [item for sublist in list_to_flatten for item in sublist]


def load_data(sales_path: str, stores_path: str, products_path: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    sales = pd.read_parquet(sales_path)
    stores = pd.read_parquet(stores_path)
    products = pd.read_parquet(products_path)

    return sales, stores, products


def prepare_cluster_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.rename(columns={"group": "Cluster"})

    return df


def make_pareto_cluster(df: pd.DataFrame,
                        quantity_column: str,
                        product_granularity: str,
                        pareto_percentage_cluster: int = 80) -> pd.DataFrame:
    """Compute the Pareto of SalesUnit (grouped by SubGroup) by Cluster"""
    filtered_df = df[[product_granularity, "Cluster", quantity_column]].copy()
    count_grouped_df = filtered_df.groupby(['Cluster', product_granularity])[quantity_column].sum().rename("count")
    pareto_df = (pd.DataFrame(count_grouped_df / count_grouped_df.groupby(level=0).sum())
                 .sort_values(by=["Cluster",
                                  "count"],
                              ascending=False)
                 .reset_index())
    pareto_df["Cumulative_Sum"] = pareto_df.groupby(by="Cluster")["count"].cumsum()
    pareto_df = pareto_df[pareto_df["Cumulative_Sum"] <= pareto_percentage_cluster / 100].drop(columns=["count"])

    return pareto_df


def make_pareto_store(df: pd.DataFrame,
                      quantity_column: str,
                      product_granularity: str,
                      store_granularity: str,
                      pareto_percentage_store: int = 101) -> pd.DataFrame:
    """Compute the Pareto of SalesUnit (grouped by SubGroup) by Cluster"""
    filtered_df = df[[product_granularity, store_granularity, quantity_column]].copy()
    count_grouped_df = filtered_df.groupby([store_granularity, product_granularity])[quantity_column].sum().rename(
        "count")
    pareto_df = (pd.DataFrame(count_grouped_df / count_grouped_df.groupby(level=0).sum())
                 .sort_values(by=[store_granularity, "count"],
                              ascending=False)
                 .reset_index())
    pareto_df["Cumulative_Sum"] = pareto_df.groupby(by=store_granularity)["count"].cumsum()
    pareto_df = pareto_df[pareto_df["Cumulative_Sum"] <= pareto_percentage_store / 100].drop(columns=["count"])

    return pareto_df


def make_pareto_store_cluster(df: pd.DataFrame,
                              quantity_column: str,
                              store_granularity: str,
                              pareto_percentage_store_clusters: int = 81) -> pd.DataFrame:
    """Compute the Pareto of SalesUnit (grouped by SubGroup) by Cluster"""
    filtered_df = df[[store_granularity, "Cluster", quantity_column]].copy()
    count_grouped_df = filtered_df.groupby(['Cluster', store_granularity])[quantity_column].sum().rename("count")
    pareto_df = (pd.DataFrame(count_grouped_df / count_grouped_df.groupby(level=0).sum())
                 .sort_values(by=["Cluster", "count"],
                              ascending=False)
                 .reset_index())
    pareto_df["Cumulative_Sum"] = pareto_df.groupby(by="Cluster")["count"].cumsum()
    pareto_df = pareto_df[pareto_df["Cumulative_Sum"] <= pareto_percentage_store_clusters / 100].drop(columns=["count"])

    return pareto_df


def make_missing_products_table(store_pareto: pd.DataFrame,
                                store_cluster_pareto: pd.DataFrame,
                                cluster_pareto: pd.DataFrame,
                                store_granularity: str,
                                product_granularity: str) -> pd.DataFrame:
    products_by_store = (pd.DataFrame(store_pareto.groupby(by=store_granularity)[product_granularity].apply(list))
                         .merge(pd.DataFrame(store_cluster_pareto.merge(cluster_pareto, on="Cluster")[[store_granularity,
                                                                                                       product_granularity]]
                                             .groupby(by=store_granularity)[product_granularity].apply(list))
                                .rename(columns={product_granularity: "DemandProducts"}), on=store_granularity))
    products_by_store = products_by_store.reset_index()

    products_by_store['MissingProducts'] = [list(set(a).difference(set(b))) for a, b in
                                            zip(products_by_store["DemandProducts"], products_by_store[product_granularity])]

    return products_by_store[[store_granularity, "MissingProducts"]]
