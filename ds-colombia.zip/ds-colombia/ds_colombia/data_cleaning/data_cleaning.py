import pandas as pd
import datetime as dt


def data_cleaning(df: pd.DataFrame, sale_id: str,
                  product_granularity: str, customer_granularity: str,
                  value_column: str, date_column: str):
    """
    Remove invalid rows of the sales dataframe with the following priority:
    1 - invalid product information
    2 - invalid sale value information
    3 - invalid customer information
    4 - invalid sale date information
    Args:
        df {pandas DataFrame}: a table containing the products per sale information
        product_granularity {str}: string identifying the product id column
        customer_granularity {str}: string identifying the customer id column
        value_column {str}: string identifying the product value in a sale column
        date_column {str}: string identifying the sale date column

    Returns:
        df {pandas DataFrame}: a table containing the products per sale information
        excluded_df {pandas DataFrame}: a table containing all excluded rows
        consolidated_table_df {pandas DataFrame}: a table informing how many rows were excluded for each reason
    """

    # first criteria: there must be a valid product in the sale to perform any analysis
    invalid_products_mask = (df[product_granularity] == -1)
    invalid_products_df = df[invalid_products_mask][sale_id].to_frame()
    invalid_products_df['exclusion reason'] = 'invalid product id'
    df = df[~invalid_products_mask]

    # second criteria: the value of a sale must be a positive number
    invalid_sale_value_mask = ((df[value_column].isna()) | (df[value_column] < 0))
    invalid_sale_value_df = df[invalid_sale_value_mask][sale_id].to_frame()
    invalid_sale_value_df['exclusion reason'] = 'non positive sale value'
    df = df[~invalid_sale_value_mask]

    # third criteria: there must be a valid customer identification on the sale to perform any analysis
    invalid_customer_mask = (df[customer_granularity] == -1)
    invalid_customer_df = df[invalid_customer_mask][sale_id].to_frame()
    invalid_customer_df['exclusion reason'] = 'invalid customer id'
    df = df[~invalid_customer_mask]

    # fourth criteria: there will not be allowed any dates after the execution date or
    # before 01-01-1900, the birthday of Jesus Christ or an invalid date all together
    invalid_date_mask = ((df[date_column] == 'N/A') | (df[date_column] == -1))
    invalid_date_df = df[invalid_date_mask][sale_id].to_frame()
    invalid_date_df['exclusion reason'] = 'invalid sale date'
    df = df[~invalid_date_mask]

    early_date_mask = (df[date_column] < pd.datetime(1900, 1, 1))
    early_date_df = df[early_date_mask][sale_id].to_frame()
    early_date_df['exclusion reason'] = 'sale date before 1900-01-01'
    df = df[~early_date_mask]

    late_date_mask = (df[date_column] > dt.datetime.today())
    late_date_df = df[late_date_mask][sale_id].to_frame()
    late_date_df['exclusion reason'] = 'sale date after {}'.format(dt.datetime.today())
    df = df[~late_date_mask]

    # consolidate exclusion information
    excluded_df = pd.concat([invalid_products_df, invalid_sale_value_df, invalid_customer_df,
                             invalid_date_df, early_date_df, late_date_df]).reset_index()
    consolidated_table_df = pd.pivot_table(excluded_df,
                                           values=[sale_id],
                                           index=['exclusion reason'],
                                           aggfunc=lambda x: len(x))

    # return all the dataframes
    return df, excluded_df, consolidated_table_df
