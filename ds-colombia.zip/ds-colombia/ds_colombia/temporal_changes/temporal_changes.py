import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def get_greater_changes(df: pd.DataFrame,
                        group_column: str,
                        value_column: str,
                        date_column: str,
                        top_n_targets: int,
                        initial_date: str,
                        end_date: str) -> pd.DataFrame:
    """
    Computes biggest changes in one category from two dates
    Args:
        df: data in a pandas DataFrame format
        group_column: name of the column to group
        value_column: value to group by
        date_column: date to filter the before and after periods
        top_n_targets: limit number of targets
        initial_date: initial date in granularity days, months or years
        end_date: end date in granularity days, months or years

    Returns:
        Pandas DataFrame with groups with largest value changes between periods with relative changes (%)
    """
    top_targets_list = (
        df[[group_column, value_column]]
            .groupby(by=group_column)
            .sum()
            .sort_values(by=value_column, ascending=False)
            .head(top_n_targets)
            .index.values
    )

    filtered_df = df[df[group_column].isin(top_targets_list)].copy()
    # This implementation assumes filtering on days, months or years, this doesn't apply to weeks, quarters or other
    # time aggregates
    before = filtered_df[[date_column, group_column, value_column]].set_index(date_column)[initial_date].copy()
    before = before.groupby(by=group_column).sum().rename(columns={value_column: "before"})
    after = filtered_df[[date_column, group_column, value_column]].set_index(date_column)[end_date].copy()
    after = after.groupby(by=group_column).sum().rename(columns={value_column: "after"})

    both = after.merge(before, on=group_column)

    both["percentual_change"] = 100 * (both["after"] - both["before"]) / both["before"]
    both["abs_percentual_change"] = both["percentual_change"].apply(lambda x: abs(x))
    both = both.sort_values(by="abs_percentual_change", ascending=False)

    try:
        both = both.drop('')
    except:
        pass

    try:
        both = both.drop("N/A")
    except:
        pass

    return both


def plot_changes(df_greater_changes: pd.DataFrame, title: str):
    plt.figure(figsize=[21, 9], dpi=300)

    plt.title(f"Changes by {df_greater_changes.index.name} - {title}", fontsize=20)
    plt.ylabel("% Change", fontsize=14)
    df_greater_changes["percentual_change"].plot(kind='bar')
    sns.despine(bottom=True, left=True)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    plt.xlabel("")
    plt.show()
