import pandas as pd
from fbprophet import Prophet
from datetime import datetime
from fbprophet.plot import plot_plotly
import plotly.offline as py


def prepare_df(df: pd.DataFrame, date_column: str, value_column: str, frequency: str = 'D') -> pd.DataFrame:
    """Prepare pandas DataFrame to Fit Prophet model

    Arguments:
        df {pandas DataFrame} -- DataFrame with a date column and a value column of interest
        date_column {str} -- Name of the date column in a timestamp data type
        value_column {str} -- Name of the value column

    Keyword Arguments:
        frequency {str} -- Frequency of the date (default: {'D'})

    Returns:
        pandas DataFrame -- DataFrame with 'ds' and 'y' columns to forecast
    """

    prepared_df = df.rename(columns={date_column: 'ds',
                                     value_column: 'y'})[['ds', 'y']].copy()
    prepared_df = prepared_df.groupby(by='ds').sum().reset_index()

    prepared_df = prepared_df.groupby(pd.Grouper(
        key='ds', freq=frequency)).sum().reset_index()

    return prepared_df


def saturate_limits(df: pd.DataFrame, cap_value: int, floor_value: int = 0) -> pd.DataFrame:
    """Pass saturating limits to forecast

    Arguments:
        df {pandas DataFrame} -- DataFrame previously prepared with 'ds' and 'y' columns
        cap_value {int} -- Superior saturating limit

    Keyword Arguments:
        floor_value {int} -- Inferior saturating limit (default: {0})

    Returns:
        pandas DataFrame -- DataFrame with ['ds', 'y', 'floor', 'cap'] columns
    """

    saturate_df = df.copy()
    saturate_df['floor'] = floor_value
    saturate_df['cap'] = cap_value

    return saturate_df


def fit_model(df: pd.DataFrame,
              growth: str = 'logistic',
              daily_seasonality: bool = False,
              weekly_seasonality: bool = True,
              yearly_seasonality: bool = True,
              seasonality_mode: str = 'additive'):
    """Fit forecast model to pandas DataFrame

    Arguments:
        df {pandas DataFrame} -- Previously prepared DataFrame

    Keyword Arguments:
        growth {str} -- Growth parameter for forecasting (default: {'logistic'})
        daily_seasonality {bool} -- Activate daily seasonality (default: {False})
        weekly_seasonality {bool} -- Activate weekly seasonality (default: {True})
        yearly_seasonality {bool} -- Activate yearly seasonality (default: {True})
        seasonality_mode {str} -- Seasonality mode (default: {'additive'})

    Returns:
        Prophet model -- Fitted Prophet model
    """
    forecast_model = Prophet(growth=growth,
                             daily_seasonality=daily_seasonality,
                             weekly_seasonality=weekly_seasonality,
                             yearly_seasonality=yearly_seasonality,
                             seasonality_mode=seasonality_mode)
    forecast_model.fit(df)

    return forecast_model


def make_forecast_df(forecast_model: Prophet,
                     cap_value: int,
                     floor_value: int = 0,
                     period: int = 365,
                     frequency: str = 'D') -> pd.DataFrame:
    """Make pandas DataFrame with predictions from Prophet model

    Arguments:
        m {Prophet Model} -- Fitted Prophet model
        cap_value {int} -- Superior saturating limit

    Keyword Arguments:
        floor_value {int} -- Inferior saturating limit (default: {0})
        period {int} -- Period to forecast (default: {365})
        frequency {str} -- minimum time unit to forecast (default: {'D'})

    Returns:
        pandas DataFrame -- DataFrame with forecast predictions
    """
    future = forecast_model.make_future_dataframe(periods=period, freq=frequency)
    future['floor'] = floor_value
    future['cap'] = cap_value
    forecast_table = forecast_model.predict(future)

    return forecast_table


def save_static_plots(forecast_model: Prophet, forecast_table: pd.DataFrame, path: str) -> None:
    """Save static plots from Forecast

    Arguments:
        m {Prophet model} -- Fitted Prophet model
        forecast {pandas DataFrame} -- DataFrame with forecast predictions
        path {str} -- Directory to save the forecast artifacts
    """
    fig = forecast_model.plot(forecast_table)
    fig_components = forecast_model.plot_components(forecast_table)

    fig.savefig('{}/forecast_{}.png'.format(path, str(datetime.now())[:10]))
    fig_components.savefig(
        '{}/forecast_components_{}.png'.format(path, str(datetime.now())[:10]))


def save_interactive_plot(forecast_model: Prophet, forecast_table: pd.DataFrame, path: str) -> None:
    """Save interactive plots from Forecast

    Arguments:
        m {Prophet model} -- Fitted Prophet model
        forecast {pandas DataFrame} -- DataFrame with forecast predictions
        path {str} -- Directory to save the forecast artifacts
    """
    fig = plot_plotly(forecast_model, forecast_table)  # This returns a plotly Figure
    py.plot(fig, filename='{}/forecast_interactive_{}.html'.format(path,
                                                                   str(datetime.now())[:10]), auto_open=False)


def save_values_spreadsheet(forecast_table: pd.DataFrame, path: str) -> None:
    """Save spreadsheet from Forecast

    Arguments:
        m {Prophet model} -- Fitted Prophet model
        forecast {pandas DataFrame} -- DataFrame with forecast predictions
        path {str} -- Directory to save the forecast artifacts
    """
    table = forecast_table[['ds', 'yhat']].copy()

    with pd.ExcelWriter('{}/forecast_{}.xlsx'.format(path, str(datetime.now())[:10]),
                        engine='xlsxwriter') as writer:
        table.to_excel(writer, sheet_name='Forecast', index=False)
        workbook = writer.book
        sheets = ['Forecast']
        for sheet_name in sheets:
            worksheet = writer.sheets[sheet_name]
            fmt = workbook.add_format({'align': 'center',
                                       'bold': False})
            worksheet.set_zoom(90)
            worksheet.set_column('A:B', 50, fmt)


def df_to_forecast(df: pd.DataFrame,
                   date_column: str,
                   value_column: str,
                   frequency: str,
                   path: str,
                   growth: str = 'logistic',
                   cap_value: int = 1e6,
                   period: int = 365,
                   floor_value: int = 0,
                   daily_seasonality: bool = False,
                   weekly_seasonality: bool = True,
                   yearly_seasonality: bool = True,
                   seasonality_mode: str = 'additive') -> None:
    """Receives data to forecast (Pandas DataFrame) and save forecast artifacts
    to given path (static and interactive plots, spreadsheet)

    Arguments:
        df {pandas DataFrame} -- DataFrame with a date column and a value column of interest
        date_column {str} -- Name of the date column
        value_column {str} -- Name of the value column
        frequency {str} -- Minimum date unit to forecast
        path {str} -- Directory to save the forecast artifacts

    Keyword Arguments:
        growth {str} -- Growth parameter of forecast (default: {'logistic'})
        cap_value {int} -- Superior saturating limit (default: {1e6})
        period {int} -- Period to forecast (default: {365})
        floor_value {int} -- Inferior saturating limit (default: {0})
        daily_seasonality {bool} -- Activate daily seasonality (default: {False})
        weekly_seasonality {bool} -- Activate weekly seasonality (default: {True})
        yearly_seasonality {bool} -- Activate yearly seasonality (default: {True})
        seasonality_mode {str} -- Seasonality mode (default: {'additive'})
    """
    df = prepare_df(df, date_column, value_column, frequency)

    df = saturate_limits(df, cap_value, floor_value)

    m = fit_model(df, growth, daily_seasonality,
                  weekly_seasonality, yearly_seasonality, seasonality_mode)

    forecast = make_forecast_df(m, cap_value, floor_value, period, frequency)

    save_static_plots(m, forecast, path)

    save_interactive_plot(m, forecast, path)

    save_values_spreadsheet(forecast, path)
