import pandas as pd
from lifetimes.utils import summary_data_from_transaction_data
from lifetimes import BetaGeoFitter
from lifetimes import GammaGammaFitter
from datetime import date


def create_transactional_table(df: pd.DataFrame,
                               customer_column: str,
                               date_column: str,
                               value_column: str) -> pd.DataFrame:
    """
    Prepare the data for creating the summary table

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame with transactional data
    customer_column : str
        Name of the customer column
    date_column : str
        Name of the date column
    value_column : str
        Name of the value column

    Returns
    ----------
    transactional : pandas.DataFrame
        DataFrame filtered with the relevant data
    """

    transactional = ((df.groupby(by=[customer_column, date_column]).sum()
                                                                   .rename(columns={customer_column: 'aux1',
                                                                                    date_column: 'aux2'})
                                                                   .reset_index()[[date_column,
                                                                                   customer_column,
                                                                                   value_column]])
                     .rename(columns={customer_column: 'id',
                                      date_column: 'date'}))

    return transactional


def create_summary_table(transactional: pd.DataFrame,
                         value_column: str,
                         end_date: str) -> (pd.DataFrame, pd.DataFrame):
    """
    Transform the transactional table in a summary table

    Parameters
    ----------
    transactional : pandas.DataFrame
        Prepared DataFrame
    value_column : str
        Name of the value column
    end_date : str
        Final date to compute the CLV

    Returns
    ----------
    summary: pandas.DataFrame
        Summary table in a RFM fashion
    inv_cust_summary: pandas.DataFrame
        Summary table of ignored customers
    """
    summary = summary_data_from_transaction_data(transactional,
                                                 customer_id_col='id',
                                                 datetime_col='date',
                                                 monetary_value_col=value_column,
                                                 observation_period_end=end_date)

    inv_cust_summary = summary[(summary['monetary_value'] == 0) |
                               (summary.index == -1)]
    inv_cust_summary = inv_cust_summary.reset_index().drop(['frequency', 'recency', 'T'], axis=1)
    summary = summary[(summary['monetary_value'] != 0) &
                      (summary.index != -1)]

    return summary, inv_cust_summary


def fit_models(summary: pd.DataFrame,
               penalizer_coef: float) -> (GammaGammaFitter, BetaGeoFitter):
    """
    Fit the GammaGamma model and BetaGeo model to the summary table

    Parameters
    ----------
    summary : pandas DataFrame
        Summary table
    penalizer_coef : int 
        Penalizer coefficient

    Returns
    ----------
    ggf : model
        fitted model
    bgf : model
        fitted model
    """
    ggf = GammaGammaFitter(penalizer_coef=penalizer_coef)
    ggf.fit(summary['frequency'],
            summary['monetary_value'])

    bgf = BetaGeoFitter(penalizer_coef=penalizer_coef)
    bgf.fit(summary['frequency'], summary['recency'], summary['T'])

    return ggf, bgf


def compute_clv(ggf: GammaGammaFitter,
                bgf: BetaGeoFitter,
                summary: pd.DataFrame,
                period: int,
                discount_rate: float) -> pd.DataFrame:
    """
    Compute the Customer Lifetime Value for the provided models

    Parameters
    ----------
    ggf : model
        GammaGamma model
    bgf : model
        BetaGeoFitter model
    summary : pandas.DataFrame
        Summary table
    period : int
        Period to compute the CLV in months
    discount_rate : float
        Discount rate

    Returns
    ----------
    clv : pandas.DataFrame
        Customer Lifetime Value table
    """
    clv = pd.DataFrame(ggf.customer_lifetime_value(bgf,
                                                   summary['frequency'],
                                                   summary['recency'],
                                                   summary['T'],
                                                   summary['monetary_value'],
                                                   time=period,
                                                   discount_rate=discount_rate
                                                   )
                       )

    clv['p_alive'] = bgf.conditional_probability_alive(summary['frequency'],
                                                       summary['recency'],
                                                       summary['T']
                                                       )

    return clv


def df_to_clv(df: pd.DataFrame,
              customer_column: str,
              date_column: str,
              value_column: str,
              end_date = date.today().strftime("%Y-%m-%d"),
              penalizer_coef = 0.1,
              period = 12,
              discount_rate = 0.01,
              clv_group_ranges = [0, 0.5, 0.80, 0.9375, 0.98435, 1],
              clv_group_labels = ['Low-Low', 'Low', 'Medium', 'High', 'High-High'],
              churn_groups_bins = 3,
              churn_groups_labels = ['churn', 'medium', 'alive']) -> pd.DataFrame:
    """
    Receives transactional data (Pandas DataFrame) and returns
    a CLV/Churn table (Pandas DataFrame)

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame with columns to compute CLV
    customer_column : str
        Name of the customer column
    date_column : str
        Name of the date column
    value_column : str
        Name of the value column
    end_date : str
        Final date to compute the CLV - format "Y-m-d" (default: {day of execution})
    penalizer_coef : float
        Penalizer coefficent (default: : {0.1})
    period : int
        Period in months to compute the CLV (default: : {12})
    discount_rate : float
        Discount rate (default: : {0.01}) ~ 12.7% annually
    clv_group_ranges : list
        CLV group ranges (default: : {[0, 0.5, 0.80, 0.9375, 0.98435, 1]})
    clv_group_labels : list
        CLV group labels (default: : {['Low-Low', 'Low','Medium', 'High', 'High-High']})
    churn_groups_bins : int
        Churn group bins (default: : {3})
    churn_groups_labels : list
        Churn group labels (default: {['churn', 'medium', 'alive']})

    Returns
    ----------
    clv : pandas.DataFrame
        Complete CLV/Churn table
    """

    transactional = create_transactional_table(
        df, customer_column, date_column, value_column)

    summary, inv_cust_summary = create_summary_table(transactional, value_column, end_date)

    ggf, bgf = fit_models(summary, penalizer_coef)

    clv = compute_clv(ggf, bgf, summary, period, discount_rate)

    # Create group segmentation based on the CLV values
    clv_group_ranges = [0, 0.5, 0.80, 0.9375, 0.98435, 1]
    clv_group_labels = ['Low-Low', 'Low', 'Medium', 'High', 'High-High']
    clv['clv_group'] = pd.qcut(clv['clv'],
                               q=clv_group_ranges,
                               labels=clv_group_labels)

    # Create churn segmentation based on the p_alive values
    churn_groups_bins = 3
    churn_groups_labels = ['churn', 'medium', 'alive']
    clv['retention_groups'] = pd.cut(clv['p_alive'],
                                     bins=churn_groups_bins,
                                     labels=churn_groups_labels)

    # Add column indicating year-month of the calculation
    clv['year_month'] = end_date[:7]  # cuts string yyyy-mm-dd to yyyy-mm

    return clv, inv_cust_summary
