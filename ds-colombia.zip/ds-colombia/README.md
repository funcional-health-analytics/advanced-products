# Advanced Analytics Python Functions 

This repository contains the code that wraps the main functions for the advanced analytics products

# Instalation

Currently only available from source (private git repository)

```bash
git clone https://github.com/funcional-health-analytics/ds-colombia.git
cd ds-colombia
git checkout master
pip install -e .
```


## Example usage

```python
import pandas as pd
from ds_colombia.forecast.forecast import df_to_forecast

df = pd.read_parquet('../data/forecast/sales.parquet.gzip')

df_to_forecast(df,
               date_column='SaleDate',
               value_column='SaleTotalPrice',
               frequency='D',
               path='../data/forecast',
               growth='logistic',
               cap_value=2e9,
               period=365,
               floor_value=0,
               daily_seasonality=False,
               weekly_seasonality=True,
               yearly_seasonality=True,
               seasonality_mode='additive')
```


## How to run the tests

1. Clone the repository and navigate to the root folder
2. Run
```bash
python -m unittest discover
```

## Documentation

### How to build
```bash
git clone https://github.com/funcional-health-analytics/ds-colombia.git
cd docs
make html
```

### How to host
```bash
python3 -m http.server
```

The documentation will be online on:

http://localhost:8000/docs/build/html/